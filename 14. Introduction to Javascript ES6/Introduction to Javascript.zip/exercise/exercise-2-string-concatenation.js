// String concatenation means add strings together.
// Use the + character to add a variable to another variable:

// Example :

let firstName = "Resky";
let lastName = "Alamsyah";

console.log("Hello my name is " + firstName + " " + lastName + ", you can call me " + firstName);

// The output should be :
// Hello my name is Resky Alamsyah, you can call me Resky